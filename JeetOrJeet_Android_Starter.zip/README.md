# JEET OR JEET — Android starter app

This is the first Android Studio project for the JEET OR JEET demo gaming app.

## Included
- Kotlin + Jetpack Compose Android app
- Bengali/English toggle
- Home dashboard
- Four free demo game tiles
- Virtual coin counter (demo only)
- Profile and history placeholder screens

## Build
1. Install Android Studio (current stable).
2. Open this folder as an existing project.
3. Allow Gradle sync and install the required Android SDK (API 35).
4. Select the `app` run configuration and run on an Android device/emulator.
5. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important
This is a demo starter, not a production-ready service. It has no real-money betting, deposits, withdrawals, backend, or payment integration. Do not add real-money wagering or prize payouts. Any paid features must be reviewed for applicable Indian law and Google Play policy before implementation.

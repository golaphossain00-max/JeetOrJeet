package com.jeetorjeet.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF10152B)
private val Panel = Color(0xFF202B4A)
private val Gold = Color(0xFFFFD45A)
private val Purple = Color(0xFF762BEE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JeetApp() }
    }
}

data class Game(val name: String, val subtitle: String, val icon: String)

@Composable
fun JeetApp() {
    var page by remember { mutableStateOf("Home") }
    var bengali by remember { mutableStateOf(true) }
    var coins by remember { mutableIntStateOf(1000) }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    val games = listOf(
        Game("Sky Flight", "Flying challenge • উড়ান খেলা", "✈️"),
        Game("Number Puzzle", "Brain challenge • সংখ্যার খেলা", "🔢"),
        Game("Lucky Wheel", "Free spin • চাকা ঘোরান", "🎡"),
        Game("Card Match", "Memory challenge • মনে রাখুন", "🃏")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Navy, surface = Panel
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🏆", fontSize = 30.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("JEET OR JEET", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text("PLAY • CHALLENGE • ENJOY", color = Color.LightGray, fontSize = 10.sp)
                    }
                    TextButton(onClick = { bengali = !bengali }) {
                        Text(if (bengali) "বাংলা" else "EN", color = Gold)
                    }
                }
                if (selectedGame != null) {
                    GameScreen(game = selectedGame!!, onBack = { selectedGame = null })
                } else if (page == "Profile") {
                    ProfileScreen(coins)
                } else if (page == "History") {
                    HistoryScreen()
                } else {
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text(if (bengali) "স্বাগতম, Player!" else "Welcome, Player!", color = Color.White, fontSize = 20.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(if (bengali) "আপনার ভার্চুয়াল কয়েন" else "Your Virtual Coins", color = Color.LightGray)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🪙  $coins", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    AssistChip(onClick = { coins += 100 }, label = { Text("+100 Demo") })
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(if (bengali) "আমাদের গেম" else "OUR GAMES", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(games) { game ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().height(145.dp)
                                        .clickable { selectedGame = game },
                                    colors = CardDefaults.cardColors(containerColor = Panel),
                                    shape = RoundedCornerShape(18.dp)
                                ) {
                                    Column(
                                        Modifier.fillMaxSize().padding(14.dp),
                                        verticalArrangement = Arrangement.Center,
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(game.icon, fontSize = 38.sp)
                                        Spacer(Modifier.height(8.dp))
                                        Text(game.name, color = Gold, fontWeight = FontWeight.Bold)
                                        Text(game.subtitle, color = Color.LightGray, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                NavigationBar(containerColor = Color(0xFF171F39)) {
                    NavigationBarItem(selected = page == "Home", onClick = { page = "Home"; selectedGame = null },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text(if (bengali) "হোম" else "Home") })
                    NavigationBarItem(selected = page == "Games", onClick = { page = "Home"; selectedGame = null },
                        icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text(if (bengali) "গেম" else "Games") })
                    NavigationBarItem(selected = page == "History", onClick = { page = "History"; selectedGame = null },
                        icon = { Icon(Icons.Default.History, null) }, label = { Text(if (bengali) "ইতিহাস" else "History") })
                    NavigationBarItem(selected = page == "Profile", onClick = { page = "Profile"; selectedGame = null },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text(if (bengali) "প্রোফাইল" else "Profile") })
                }
            }
        }
    }
}

@Composable
fun GameScreen(game: Game, onBack: () -> Unit) {
    var score by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(game.name, color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(35.dp))
        Text(game.icon, fontSize = 76.sp)
        Text(game.name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Free demo game • কোনো আসল টাকা নয়", color = Color.LightGray)
        Spacer(Modifier.height(30.dp))
        Text("Score: $score", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Button(onClick = { score += (1..10).random() },
            colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
            Text("PLAY DEMO", color = Color.White)
        }
        Text("এটি একটি বিনামূল্যের ডেমো।", color = Color.LightGray, modifier = Modifier.padding(top = 20.dp))
    }
}

@Composable
fun ProfileScreen(coins: Int) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("👤", fontSize = 64.sp)
        Text("Player", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Demo Account", color = Color.LightGray)
        Spacer(Modifier.height(20.dp))
        Text("Virtual Coins: $coins", color = Color.White, fontSize = 20.sp)
        Text("Account settings and secure sign-in will be added in the next build.", color = Color.LightGray)
    }
}

@Composable
fun HistoryScreen() {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Game History", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("এখনও কোনো গেম খেলা হয়নি।", color = Color.White)
        Text("পরবর্তী সংস্করণে গেমের ফলাফল সংরক্ষণ করা হবে।", color = Color.LightGray)
    }
}

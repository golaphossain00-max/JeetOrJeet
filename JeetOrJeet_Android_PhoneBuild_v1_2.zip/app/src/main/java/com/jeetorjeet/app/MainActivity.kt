package com.jeetorjeet.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.MessageDigest

private val Navy = Color(0xFF10152B)
private val Panel = Color(0xFF202B4A)
private val Gold = Color(0xFFFFD45A)
private val Purple = Color(0xFF762BEE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JeetApp(applicationContext) }
    }
}

data class Game(val name: String, val subtitle: String, val icon: String)

private fun hash(value: String): String {
    return MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

@Composable
fun JeetApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("jeet_demo_account", Context.MODE_PRIVATE) }
    var loggedIn by remember { mutableStateOf(prefs.getBoolean("logged_in", false)) }
    var playerName by remember { mutableStateOf(prefs.getString("player_name", "") ?: "") }
    var page by remember { mutableStateOf("Home") }
    var bengali by remember { mutableStateOf(true) }
    var coins by remember { mutableIntStateOf(1000) }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    var message by remember { mutableStateOf("") }

    val games = listOf(
        Game("Sky Flight", "Flying challenge • উড়ান খেলা", "✈️"),
        Game("Number Puzzle", "Brain challenge • সংখ্যার খেলা", "🔢"),
        Game("Lucky Wheel", "Free spin • চাকা ঘোরান", "🎡"),
        Game("Card Match", "Memory challenge • মনে রাখুন", "🃏")
    )

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Navy, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (!loggedIn) {
                AuthScreen(
                    bengali = bengali,
                    onLanguage = { bengali = !bengali },
                    onLogin = { mobile, password ->
                        val savedMobile = prefs.getString("mobile", null)
                        val savedHash = prefs.getString("password_hash", null)
                        if (savedMobile == mobile && savedHash == hash(password)) {
                            playerName = prefs.getString("player_name", "Player") ?: "Player"
                            prefs.edit().putBoolean("logged_in", true).apply()
                            loggedIn = true
                            message = ""
                        } else message = if (bengali) "মোবাইল নম্বর বা পাসওয়ার্ড মিলছে না। আগে রেজিস্ট্রেশন করুন।" else "Invalid login. Please register first."
                    },
                    onRegister = { name, mobile, password ->
                        if (name.isBlank() || mobile.length < 10 || password.length < 6) {
                            message = if (bengali) "নাম, সঠিক মোবাইল নম্বর এবং অন্তত ৬ অক্ষরের পাসওয়ার্ড দিন।" else "Enter name, valid mobile and a password of at least 6 characters."
                        } else {
                            prefs.edit()
                                .putString("player_name", name)
                                .putString("mobile", mobile)
                                .putString("password_hash", hash(password))
                                .putBoolean("logged_in", true)
                                .apply()
                            playerName = name
                            loggedIn = true
                            message = ""
                        }
                    },
                    message = message
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🏆", fontSize = 30.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("JEET OR JEET", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("PLAY • CHALLENGE • ENJOY", color = Color.LightGray, fontSize = 10.sp)
                        }
                        TextButton(onClick = { bengali = !bengali }) { Text(if (bengali) "বাংলা" else "EN", color = Gold) }
                    }

                    when {
                        selectedGame != null -> GameScreen(selectedGame!!, onBack = { selectedGame = null })
                        page == "Profile" -> ProfileScreen(
                            playerName, coins,
                            onAdmin = { page = "Admin" },
                            onLogout = {
                                prefs.edit().putBoolean("logged_in", false).apply()
                                loggedIn = false
                                page = "Home"
                            }
                        )
                        page == "History" -> HistoryScreen()
                        page == "Admin" -> AdminScreen(onBack = { page = "Profile" })
                        else -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                    Text(if (bengali) "স্বাগতম, $playerName!" else "Welcome, $playerName!", color = Color.White, fontSize = 20.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(if (bengali) "আপনার ভার্চুয়াল কয়েন" else "Your Virtual Coins", color = Color.LightGray)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🪙  $coins", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.weight(1f))
                                        AssistChip(onClick = { coins += 100 }, label = { Text("+100 Demo") })
                                    }
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            Text(if (bengali) "আমাদের গেম" else "OUR GAMES", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(games) { game ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth().height(145.dp).clickable { selectedGame = game },
                                        colors = CardDefaults.cardColors(containerColor = Panel),
                                        shape = RoundedCornerShape(18.dp)
                                    ) {
                                        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(game.icon, fontSize = 38.sp)
                                            Spacer(Modifier.height(8.dp))
                                            Text(game.name, color = Gold, fontWeight = FontWeight.Bold)
                                            Text(game.subtitle, color = Color.LightGray, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    NavigationBar(containerColor = Color(0xFF171F39)) {
                        NavigationBarItem(selected = page == "Home", onClick = { page = "Home"; selectedGame = null }, icon = { Icon(Icons.Default.Home, null) }, label = { Text(if (bengali) "হোম" else "Home") })
                        NavigationBarItem(selected = page == "Games", onClick = { page = "Home"; selectedGame = null }, icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text(if (bengali) "গেম" else "Games") })
                        NavigationBarItem(selected = page == "History", onClick = { page = "History"; selectedGame = null }, icon = { Icon(Icons.Default.History, null) }, label = { Text(if (bengali) "ইতিহাস" else "History") })
                        NavigationBarItem(selected = page == "Profile" || page == "Admin", onClick = { page = "Profile"; selectedGame = null }, icon = { Icon(Icons.Default.Person, null) }, label = { Text(if (bengali) "প্রোফাইল" else "Profile") })
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(
    bengali: Boolean, onLanguage: () -> Unit,
    onLogin: (String, String) -> Unit,
    onRegister: (String, String, String) -> Unit,
    message: String
) {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🏆", fontSize = 64.sp)
        Text("JEET OR JEET", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("PLAY • CHALLENGE • ENJOY", color = Color.LightGray, fontSize = 11.sp)
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (register) "Create Account" else "Welcome Back", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            TextButton(onClick = onLanguage) { Text(if (bengali) "বাংলা" else "EN", color = Gold) }
        }
        if (register) {
            OutlinedTextField(name, { name = it }, label = { Text(if (bengali) "নাম" else "Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(mobile, { mobile = it }, label = { Text(if (bengali) "মোবাইল নম্বর" else "Mobile number") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, label = { Text(if (bengali) "পাসওয়ার্ড" else "Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { if (register) onRegister(name, mobile, password) else onLogin(mobile, password) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text(if (register) "REGISTER / রেজিস্ট্রেশন" else "LOGIN / লগইন", color = Color.White) }
        TextButton(onClick = { register = !register }) {
            Text(if (register) "Already registered? Login" else "New user? Create account", color = Gold)
        }
        if (message.isNotBlank()) Text(message, color = Color(0xFFFF8A80), fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Text("Demo account data stays on this device only.", color = Color.LightGray, fontSize = 11.sp)
    }
}

@Composable
fun GameScreen(game: Game, onBack: () -> Unit) {
    var score by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(game.name, color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(35.dp))
        Text(game.icon, fontSize = 76.sp)
        Text(game.name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Free demo game • কোনো আসল টাকা নয়", color = Color.LightGray)
        Spacer(Modifier.height(30.dp))
        Text("Score: $score", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Button(onClick = { score += (1..10).random() }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("PLAY DEMO", color = Color.White) }
        Text("এটি একটি বিনামূল্যের ডেমো।", color = Color.LightGray, modifier = Modifier.padding(top = 20.dp))
    }
}

@Composable
fun ProfileScreen(name: String, coins: Int, onAdmin: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("👤", fontSize = 64.sp)
        Text(name, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Demo Account", color = Color.LightGray)
        Spacer(Modifier.height(20.dp))
        Text("Virtual Coins: $coins", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(18.dp))
        OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) { Text("Admin Panel (Preview)") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onLogout, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Logout / লগআউট") }
        Text("এই সংস্করণে অ্যাডমিন প্যানেল শুধু UI preview; কোনো সার্ভার নিয়ন্ত্রণ নেই।", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(top = 14.dp))
    }
}

@Composable
fun AdminScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("Admin Panel", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        listOf("User management — preview", "Game settings — preview", "Reports — preview", "Support requests — preview").forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Text(it, color = Color.White, modifier = Modifier.padding(16.dp))
            }
        }
        Text("Production admin access requires a secured server, role permissions and audit logs.", color = Color.LightGray, modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
fun HistoryScreen() {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Game History", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("এখনও কোনো গেম খেলা হয়নি।", color = Color.White)
        Text("পরবর্তী সংস্করণে গেমের ফলাফল সংরক্ষণ করা হবে।", color = Color.LightGray)
    }
}
